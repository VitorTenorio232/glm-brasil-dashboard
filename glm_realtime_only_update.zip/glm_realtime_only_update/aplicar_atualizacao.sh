#!/usr/bin/env bash
set -euo pipefail

TARGET="${1:-.}"
HERE="$(cd "$(dirname "$0")" && pwd)"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="$TARGET/_backup_antes_tempo_real_$STAMP"

mkdir -p "$BACKUP/pages" "$BACKUP/src"
for f in app.py requirements.txt pages/02_Monitoramento.py pages/03_Dados.py; do
  if [ -f "$TARGET/$f" ]; then
    mkdir -p "$BACKUP/$(dirname "$f")"
    cp "$TARGET/$f" "$BACKUP/$f"
  fi
done

mkdir -p "$TARGET/src" "$TARGET/pages"
cp "$HERE/src/realtime_glm.py" "$TARGET/src/realtime_glm.py"
cp "$HERE/pages/02_Monitoramento.py" "$TARGET/pages/02_Monitoramento.py"
cp "$HERE/pages/03_Dados.py" "$TARGET/pages/03_Dados.py"

# Mantém o requirements atual e só garante pytz.
if [ -f "$TARGET/requirements.txt" ]; then
  grep -q '^pytz\([<>=].*\)\?$' "$TARGET/requirements.txt" || echo 'pytz' >> "$TARGET/requirements.txt"
else
  echo 'pytz' > "$TARGET/requirements.txt"
fi

# Preserva todo o app.py atual e insere apenas um bloqueio "Em breve"
# antes da inicialização da base histórica.
python - "$TARGET/app.py" <<'PY'
from pathlib import Path
import sys

p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
marker = 'HISTORICAL_ANALYSIS_AVAILABLE = False'
if marker in s:
    print('app.py já está em modo histórico Em breve; nenhuma alteração adicional.')
    raise SystemExit(0)

needle = 'repo = FlashesRepository()\n'
if needle not in s:
    raise SystemExit(
        'Não encontrei "repo = FlashesRepository()" no app.py. '
        'O backup foi criado e os arquivos de tempo real foram copiados, '
        'mas o app.py não foi modificado.'
    )

block = '''# -----------------------------------------------------------------------------\n# HISTÓRICO: aguardando a base processada\n# -----------------------------------------------------------------------------\nHISTORICAL_ANALYSIS_AVAILABLE = False\n\nif not HISTORICAL_ANALYSIS_AVAILABLE:\n    st.info(\n        "🚧 **Análises históricas — Em breve.** A base GLM processada está sendo preparada "\n        "e este módulo será habilitado assim que os arquivos estiverem disponíveis."\n    )\n    st.success(\n        "📡 O **Monitoramento GLM em tempo real** já está disponível com os últimos 30 minutos."\n    )\n    st.page_link(\n        "pages/02_Monitoramento.py",\n        label="Abrir monitoramento em tempo real",\n        icon="📡",\n        use_container_width=True,\n    )\n    st.stop()\n\n'''

s = s.replace(needle, block + needle, 1)
p.write_text(s, encoding='utf-8')
print('app.py preservado e configurado com histórico = Em breve.')
PY

echo
echo "Atualização aplicada. Backup: $BACKUP"
echo "Próximos comandos:"
echo "  python -m pip install -r requirements.txt"
echo "  python -m compileall -q app.py src pages"
echo "  python -m streamlit run app.py"
