# Atualização — Monitoramento GLM em tempo real

Esta atualização mantém a arquitetura V4 e muda apenas o estado operacional do projeto:

- análises históricas: **Em breve**;
- dados históricos: **Em breve**;
- monitoramento GLM: **ativo**, consultando o NOAA/NODD AWS diretamente.

## Janela temporal

O mapa usa os últimos **30 minutos disponíveis**, divididos em:

- 0–5 min: vermelho;
- 5–10 min: azul;
- 10–20 min: verde;
- 20–30 min: amarelo.

A janela é ancorada no arquivo GLM-L2-LCFA mais recente disponível. A interface mostra a latência entre o relógio atual e o dado mais novo.

## Instalação

Copie os arquivos desta atualização para a raiz do projeto, preservando a estrutura `src/` e `pages/`.

Depois:

```bash
python -m pip install -r requirements.txt
python -m compileall -q app.py src pages
python -m streamlit run app.py
```

## Reativar o histórico futuramente

Em `app.py`, altere:

```python
HISTORICAL_ANALYSIS_AVAILABLE = False
```

para:

```python
HISTORICAL_ANALYSIS_AVAILABLE = True
```

A lógica histórica V4 abaixo do bloqueio foi preservada.
